package com.hnam.recyclerview

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.item_movie.*

class activity_detail : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        getAndPutData()
    }

    private fun getAndPutData() {
        val data = intent.extras

        if (data != null) {
            val title = data.getString(MOVIE_TITLE_KEY)
            val overview = data.getString(MOVIE_OVERVIEW_KEY)
            val poster = data.getInt(MOVIE_POSTER_KEY)


            tvOTitle.text = title
            tvDescription.text = overview
            Glide.with(this)
                .load( poster)
                .into(ivBackdrop)

        }
    }
}
