package com.hnam.recyclerview

const val MOVIE_TITLE_KEY = "MOVIE_TITLE_KEY"
const val MOVIE_OVERVIEW_KEY = "MOVIE_OVERVIEW_KEY"
const val MOVIE_POSTER_KEY = "MOVIE_POSTER_KEY"