package com.hnam.recyclerview

interface MovieItemClickListener {
    fun onItemCLicked(position: Int)
    fun onItemLongCLicked(position: Int)
}